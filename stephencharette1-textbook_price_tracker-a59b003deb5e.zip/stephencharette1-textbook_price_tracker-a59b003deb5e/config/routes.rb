Rails.application.routes.draw do
  resources :watchlist_textbooks, only: %i[create destroy]
  get 'watchlist', to: 'watchlist_textbooks#index'

  resources :textbooks
  post 'textbooks/search'

  devise_for :users

  get 'home/index'
  root 'home#index'
end
