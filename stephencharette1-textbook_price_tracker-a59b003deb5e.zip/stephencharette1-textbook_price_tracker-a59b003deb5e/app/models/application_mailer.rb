class ApplicationMailer < ActionMailer::Base
  default from: Rails.config.x.mailer_username
  layout 'mailer'
end