require 'net/http'
require 'nokogiri'
require 'open-uri'
class Textbook < ApplicationRecord
  include MoneyToString

  has_many :textbook_prices, dependent: :destroy
  has_many :watchlist_textbooks, dependent: :destroy
  has_many :users, through: :watchlist_textbooks

  validates :isbn_10, presence: true, unless: :isbn_13
  validates :isbn_13, presence: true, unless: :isbn_10, uniqueness: true
  validate :book_exists

  after_create :get_details

  API_ATTEMPTS = 3

  def brand_new_prices
    textbook_prices.brand_new
  end

  def aggregate_prices
    TextbookPrice.medium_types.each do |_medium_type, value|
      aggregate_price = textbook_prices.new(medium_type: value)

      aggregate_price.transaction do
        previous_prices = textbook_prices.where(date: ..DateTime.now.to_date - AGGREGATE_PERIOD_IN_DAYS,
                                                medium_type: value)
                                         .order(:date)

        next if previous_prices.empty?

        aggregate_price.price = previous_prices.average(:price)
        aggregate_price.date = previous_prices.last.date

        previous_prices.destroy_all
        aggregate_price.save!
      end
    end

    update(last_aggregated_at: DateTime.now.to_date)
  end

  def used_prices
    textbook_prices.used
  end

  def price_range_for_graph
    prices_descending = textbook_prices.where.not(price: nil).order(price: :desc)

    min_price = (prices_descending.last.price.to_i - 5).positive? ? prices_descending.last.price.to_i - 5 : 0
    max_price = (prices_descending.first.price + 10).to_i.round(-1)

    [min_price, max_price]
  end

  def self.search(query)
    query = query.delete('^0-9')

    return nil unless query.length == 10 || query.length == 13

    isbn_10_textbook = Textbook.find_by(isbn_10: query)
    isbn_13_textbook = Textbook.find_by(isbn_13: query) unless isbn_10_textbook.present?

    if isbn_10_textbook.nil? && isbn_13_textbook.nil?
      if Textbook.find_book(query)
        created_textbook = nil
        case query.length
        when 10
          created_textbook = Textbook.create!(isbn_10: query)
        when 13
          created_textbook = Textbook.create!(isbn_13: query)
        end

        return created_textbook
      end
    else
      return isbn_10_textbook || isbn_13_textbook
    end

    nil
  end

  # 1. Create price
  # 2. check if price_drop?
  # 3. if so, email everyone who has watchlisted.

  def price_api_string
    if isbn_13.present?
      "https://www.cheapesttextbooks.com/IM/?keyval=#{isbn_13}"
    else
      "https://www.cheapesttextbooks.com/IM/?keyval=#{isbn_10}"
    end
  end

  def image_api_string
    price_api_string
  end

  def self.details_api_string(isbn)
    "https://www.googleapis.com/books/v1/volumes?q=+isbn:#{isbn}"
  end

  def details_api_string(isbn: nil)
    if isbn_13.present?
      "https://www.googleapis.com/books/v1/volumes?q=+isbn:#{isbn_13}"
    else
      "https://www.googleapis.com/books/v1/volumes?q=+isbn:#{isbn_10}"
    end
  end

  def get_new_price(document)
    return nil unless document.is_a? Nokogiri::HTML4::Document

    logger = Logger.new($stdout)
    attempts = 0
    new_price = nil
    new_url = ''
    begin
      new_object = document.css('.new').first.children[1]
      new_price = new_object.children[1].children[1].children[0].text
      new_url = new_object.children[5].attributes['href'].value
    rescue StandardError => e
      logger.warn "#{e} for textbook: #{id}"
      attempts += 1
      retry if attempts <= API_ATTEMPTS
    end

    {
      medium_type: :brand_new,
      url: new_url,
      date: DateTime.now.to_date,
      price: new_price.present? ? money_string_to_integer(new_price) : new_price
    }
  end

  def get_used_price(document)
    return nil unless document.is_a? Nokogiri::HTML4::Document

    logger = Logger.new($stdout)
    attempts = 0
    used_price = nil
    used_url = ''
    begin
      used_object = document.css('.used').first.children[1]
      used_price = used_object.children[1].children[1].children[0].text
      used_url = used_object.children[5].attributes['href'].value
    rescue StandardError => e
      logger.warn "#{e} for textbook: #{id}"
      attempts += 1
      retry if attempts <= API_ATTEMPTS
    end

    {
      medium_type: :used,
      url: used_url,
      date: DateTime.now.to_date,
      price: used_price.present? ? money_string_to_integer(used_price) : used_price
    }
  end

  def current_new_price
    if textbook_prices.brand_new.find_by(date: DateTime.now.to_date).nil?
      create_new_price
    else
      textbook_prices.brand_new.find_by(date: DateTime.now.to_date)
    end
  end

  def current_used_price
    if textbook_prices.used.find_by(date: DateTime.now.to_date).nil?
      create_used_price
    else
      textbook_prices.used.find_by(date: DateTime.now.to_date)
    end
  end

  def current_prices
    [current_new_price, current_used_price]
  end

  def get_price
    uri = URI(price_api_string)
    response = Net::HTTP.get_response(uri)
    return unless response.is_a? Net::HTTPOK

    document = Nokogiri::HTML(response.body)

    create_new_price(document)
    create_used_price(document)
  end

  def create_new_price(document = nil)
    unless document.is_a? Nokogiri::HTML4::Document
      uri = URI(price_api_string)
      response = Net::HTTP.get_response(uri)
      document = Nokogiri::HTML(response.body)
    end

    new_price_object = get_new_price(document)
    textbook_prices.create(new_price_object) if new_price_object.present?
  end

  def create_used_price(document = nil)
    unless document.is_a? Nokogiri::HTML4::Document
      uri = URI(price_api_string)
      response = Net::HTTP.get_response(uri)
      document = Nokogiri::HTML(response.body)
    end

    used_price_object = get_used_price(document)
    textbook_prices.create(used_price_object) if used_price_object.present?
  end

  def get_image(document = nil)
    if document.nil?
      uri = URI(image_api_string)
      response = Net::HTTP.get_response(uri)
      document = Nokogiri::HTML(response.body)
    end

    return nil unless document.is_a? Nokogiri::HTML4::Document

    begin
      large_image_src = document.css('.image').first.children[3].attr('src')
      if large_image_src.nil?
        small_image_src = document.css('.image').first.children[1].attr('src')
        update!(image_src: small_image_src)
      else
        update!(image_src: large_image_src)
      end
    rescue NoMethodError
      nil
    rescue ArgumentError
      nil
    end
  end

  def book_exists
    uri = URI(details_api_string)
    response = Net::HTTP.get_response(uri)
    return false unless response.is_a? Net::HTTPOK

    json = JSON.parse(response.body)

    begin
      # json['items'] is an array of books that returned from search query
      book_info = json['items'].first['volumeInfo']
      book_info['title']
    rescue ArgumentError
      # TODO: add rescue block here and so something!
      return false
    end

    true
  end

  def self.find_book(isbn)
    uri = URI(Textbook.details_api_string(isbn))
    response = Net::HTTP.get_response(uri)
    return false unless response.is_a? Net::HTTPOK

    json = JSON.parse(response.body)

    begin
      # json['items'] is an array of books that returned from search query
      book_info = json['items'].first['volumeInfo']
      book_info['title']
    rescue Exception => e
      # TODO: add rescue block here and so something!
      return false
    end

    true
  end

  def get_details
    uri = URI(details_api_string)
    response = Net::HTTP.get_response(uri)
    return unless response.is_a? Net::HTTPOK

    json = JSON.parse(response.body)

    begin
      # json['items'] is an array of books that returned from search query
      book_info = json['items'].first['volumeInfo']
      self.title = book_info['title']
      self.subtitle = book_info['subtitle']
      self.publisher = book_info['publisher']
      self.published_date = book_info['publishedDate']
      self.description = book_info['description']

      self.author = book_info['authors'].join(', ')

      # isbn object layout: {"type"=>"ISBN_10", "identifier=>"0789723107"}
      book_info['industryIdentifiers'].each do |isbn_object|
        self.isbn_10 = isbn_object['identifier'] if isbn_object['type'] == 'ISBN_10'
        self.isbn_13 = isbn_object['identifier'] if isbn_object['type'] == 'ISBN_13'
      end
    rescue Exception => e
      # TODO: add rescue block here and so something!
    end

    save

    get_price
    get_image
  end
end
