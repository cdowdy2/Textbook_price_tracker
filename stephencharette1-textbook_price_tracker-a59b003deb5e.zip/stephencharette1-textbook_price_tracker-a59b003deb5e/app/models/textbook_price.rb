class TextbookPrice < ApplicationRecord
  belongs_to :textbook

  validates :date, presence: true
  validates :medium_type, presence: true
  validates_presence_of :price, if: :url?
  validates_uniqueness_of :date, scope: %i[textbook_id medium_type]

  after_create :email_price_drop, if: :price_drop?

  enum medium_type: %i[brand_new used]

  attr_accessor :skip_url_validation, :previous_price

  PRICE_DROP_MULTIPLIER = 0.7

  def price_drop?
    return false unless available?
    return false if aggregate?

    previous_price = textbook.textbook_prices.where(medium_type: medium_type).where.not(url: nil || '', price: nil).order(:date)[-2]

    return false unless previous_price.present?

    @previous_price = previous_price.price

    price <= (previous_price.price * PRICE_DROP_MULTIPLIER)
  end

  def email_price_drop
    return unless textbook.users.present?

    TextbookMailer.with(users: textbook.users, textbook: textbook, new_price_object: self, previous_price: @previous_price, medium_type: medium_type).price_drop_email.deliver_now
  end

  def available?
    price.present? && url.present?
  end

  def aggregate?
    price.present? && url.nil?
  end
end
