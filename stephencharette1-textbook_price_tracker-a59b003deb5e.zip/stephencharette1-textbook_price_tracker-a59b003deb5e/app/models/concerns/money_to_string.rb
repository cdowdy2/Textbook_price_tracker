module MoneyToString
  # Takes string such as: `$45.79` and returns 45.79
  def money_string_to_integer(money_string)
    money_string.scan(/[.0-9]/).join.to_f
  end
end
