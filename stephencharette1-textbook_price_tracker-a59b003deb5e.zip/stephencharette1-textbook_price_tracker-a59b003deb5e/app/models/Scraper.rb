require 'nokogiri'
require 'open-uri'
require 'net/http'
# require 'pry'
# uncomment for development, heroku doesn't like pry.

class Scraper
  url = "https://www.cheapesttextbooks.com/IM/?keyval=#{9780789723109}"
  uri = URI(url)
  response = Net::HTTP.get_response(uri)

  doc = Nokogiri::HTML(response.body)

  # binding.pry
  # uncomment for development

  # get small image url: doc.css('.image').first.children[1].attr('src')
  # get large image url: doc.css('.image').first.children[3].attr('src')
end

scrape = Scraper.new