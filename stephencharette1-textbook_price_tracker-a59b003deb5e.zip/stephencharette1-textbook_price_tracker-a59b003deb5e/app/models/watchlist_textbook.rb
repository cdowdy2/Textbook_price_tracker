class WatchlistTextbook < ApplicationRecord
  belongs_to :user
  belongs_to :textbook

  after_create :email_create_watchlist
  after_destroy :email_remove_watchlist

  validates_uniqueness_of :textbook, scope: :user, message: 'is already in your Watchlist.'


  def email_create_watchlist
    TextbookMailer.with(user: user, textbook: textbook).watchlist_email.deliver_now
  end

  def email_remove_watchlist
    TextbookMailer.with(user: user.email, textbook: textbook).watchlist_remove_email.deliver_now
  end
end
