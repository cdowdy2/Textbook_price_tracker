class WatchlistTextbooksController < ApplicationController
  before_action :authenticate_user_prompt_login
  before_action :set_textbook, only: :create
  before_action :set_watchlist_textbook, only: :destroy

  # GET /watchlist or /watchlist.json
  def index
    @watchlist_textbooks = current_user.watchlist_textbooks.order(:created_at)
  end

  # POST /watchlist_textbooks or /watchlist_textbooks.json
  def create
    @watchlist_textbook = WatchlistTextbook.new(user: current_user, textbook: @textbook)

    respond_to do |format|
      if @watchlist_textbook.save
        format.html { redirect_to watchlist_path, notice: "Textbook was added to your Watchlist." }
        format.json { render :show, status: :created, location: @watchlist_textbook }
      else
        format.html { redirect_to @textbook, alert: @watchlist_textbook.errors.full_messages.to_sentence, status: :unprocessable_entity }
        format.json { render json: @watchlist_textbook.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /watchlist_textbooks/1 or /watchlist_textbooks/1.json
  def destroy
    @watchlist_textbook.destroy

    respond_to do |format|
      format.html { redirect_to watchlist_textbooks_url, notice: "Textbook was removed from Watchlist." }
      format.json { head :no_content }
    end
  end

  private

  # Use callbacks to share common setup or constraints between actions.

  def set_textbook
    @textbook = Textbook.find(params[:id])
  end

  def set_watchlist_textbook
    @watchlist_textbook = current_user.watchlist_textbooks.find_by(textbook_id: params[:textbook_id])
  end
end
