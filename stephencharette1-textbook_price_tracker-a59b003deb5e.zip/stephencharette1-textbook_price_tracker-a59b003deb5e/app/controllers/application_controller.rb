class ApplicationController < ActionController::Base
  respond_to :html, :json
  before_action :store_user_location!, if: :storable_location?

  def authorize_admin
    redirect_to root_path, alert: 'Unauthorized access.' unless current_user.admin
  end

  def authenticate_user_prompt_login
    redirect_to user_session_path, alert: 'Please sign in or sign up to wishlist this textbook.' unless signed_in?
  end

  def after_sign_in_path_for(resource_or_scope)
    stored_location_for(resource_or_scope) || super
  end

  private

  # Its important that the location is NOT stored if:
  # - The request method is not GET (non idempotent)
  # - The request is handled by a Devise controller such as Devise::SessionsController as that could cause an 
  #    infinite redirect loop.
  # - The request is an Ajax request as this can lead to very unexpected behaviour.
  def storable_location?
    request.get? && is_navigational_format? && !devise_controller? && !request.xhr? 
  end

  def store_user_location!
    # :user is the scope we are authenticating
    store_location_for(:user, request.fullpath)
  end
end
