class TextbooksController < ApplicationController
  before_action :authenticate_user!, except: %i[show search]
  before_action :authorize_admin, except: %i[show search]
  before_action :set_textbook, only: %i[show edit update destroy]

  # GET /textbooks or /textbooks.json
  def index
    @textbooks = Textbook.all
  end

  # GET /textbooks/1 or /textbooks/1.json
  def show
    @new_price_data = {
      name: 'New', data: @textbook.brand_new_prices.group_by_day(:date).maximum(:price).compact
    }
    @used_price_data = {
      name: 'Used', data: @textbook.used_prices.group_by_day(:date).maximum(:price).compact
    }

    @current_new_price, @current_used_price = @textbook.current_prices

    @min_price, @max_price = @textbook.price_range_for_graph
  end

  # GET /textbooks/new
  def new
    @textbook = Textbook.new
  end

  # GET /textbooks/1/edit
  def edit; end

  # POST /textbooks or /textbooks.json
  def create
    @textbook = Textbook.new(textbook_params)

    respond_to do |format|
      if @textbook.save
        format.html { redirect_to textbook_url(@textbook), notice: 'Textbook was successfully created.' }
        format.json { render :show, status: :created, location: @textbook }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @textbook.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /textbooks/1 or /textbooks/1.json
  def update
    respond_to do |format|
      if @textbook.update(textbook_params)
        format.html { redirect_to textbook_url(@textbook), notice: 'Textbook was successfully updated.' }
        format.json { render :show, status: :ok, location: @textbook }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @textbook.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /textbooks/1 or /textbooks/1.json
  def destroy
    @textbook.destroy

    respond_to do |format|
      format.html { redirect_to textbooks_url, notice: 'Textbook was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  def search
    textbook = Textbook.search(params[:query])

    respond_to do |format|
      if textbook.present?
        format.html { redirect_to textbook_url(textbook) }
        format.json { render :show, status: :found, location: @textbook }
      else
        format.html do
          redirect_to root_path, alert: 'Textbook could not be found. Please check the ISBN number you have entered.'
        end
      end
    end
  end

  private

  # Use callbacks to share common setup or constraints between actions.
  def set_textbook
    @textbook = Textbook.find(params[:id])
  end

  # Only allow a list of trusted parameters through.
  def textbook_params
    params.require(:textbook).permit(:isbn_10, :release_date, :isbn_13, :author, :publisher, :title, :subtitle,
                                     :description, :published_date)
  end
end
