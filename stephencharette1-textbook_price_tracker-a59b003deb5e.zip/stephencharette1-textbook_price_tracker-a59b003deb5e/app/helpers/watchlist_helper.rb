module WatchlistHelper
end
