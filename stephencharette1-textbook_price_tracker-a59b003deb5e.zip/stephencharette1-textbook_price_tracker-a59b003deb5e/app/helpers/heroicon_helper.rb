# frozen_string_literal: true

module HeroiconHelper
  include Heroicon::Engine.helpers
end