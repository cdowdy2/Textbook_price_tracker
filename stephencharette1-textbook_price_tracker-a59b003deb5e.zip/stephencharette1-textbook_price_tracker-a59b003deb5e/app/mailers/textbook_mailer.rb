class TextbookMailer < ActionMailer::Base
  default from: Rails.configuration.x.mailer_username

  def watchlist_email
    @user = params[:user]
    @textbook = params[:textbook]
    mail(to: @user.email, subject: 'Textbook Watchlisted')
  end

  def price_drop_email
    users = params[:users]
    @textbook = params[:textbook]
    @new_price_object = params[:new_price_object]
    @previous_price = params[:previous_price]
    @medium_type = params[:medium_type]

    mail(bcc: users.pluck(:email).join(','), subject: 'Price Drop on Watchlisted Textbook')
  end

  def watchlist_remove_email
    @user = params[:user]
    @textbook = params[:textbook]
    mail(to: @user, subject: 'Watchlisted Textbook Removed')
  end

end
