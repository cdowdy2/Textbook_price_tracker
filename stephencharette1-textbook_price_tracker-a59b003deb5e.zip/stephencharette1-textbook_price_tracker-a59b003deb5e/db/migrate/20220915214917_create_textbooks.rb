class CreateTextbooks < ActiveRecord::Migration[7.0]
  def change
    create_table :textbooks do |t|
      t.string :isbn_10
      t.string :published_date
      t.string :isbn_13
      t.string :author
      t.string :publisher
      t.string :subtitle
      t.string :description
      t.string :title

      t.timestamps
    end
  end
end
