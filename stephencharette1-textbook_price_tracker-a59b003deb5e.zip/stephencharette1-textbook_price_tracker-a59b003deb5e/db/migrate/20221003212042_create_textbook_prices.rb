class CreateTextbookPrices < ActiveRecord::Migration[7.0]
  def change
    create_table :textbook_prices do |t|
      t.date :date
      t.decimal :price
      t.string :url
      t.integer :medium_type

      t.references :textbook
      t.timestamps
    end
  end
end
