require "test_helper"

class TextbookMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
