# Preview all emails at http://localhost:3000/rails/mailers/textbook_mailer
class TextbookMailerPreview < ActionMailer::Preview
  def price_drop_email
    textbook = Textbook.last
    previous_price = 100
    new_price_object = textbook.textbook_prices.used.where.not(price: nil).where.not(url: nil).last
    medium_type = :used

    TextbookMailer.with(users: User.all, textbook: textbook, new_price_object: new_price_object, previous_price: previous_price, medium_type: medium_type).price_drop_email
  end
end
