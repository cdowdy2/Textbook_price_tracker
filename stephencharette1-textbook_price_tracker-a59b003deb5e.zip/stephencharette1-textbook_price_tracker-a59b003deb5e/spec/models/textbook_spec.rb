require 'rails_helper'
RSpec.describe Textbook, type: :model do
  before(:example) do
    @valid_textbook = create(:textbook, :valid)
    @invalid_textbook = build(:textbook, :invalid)
  end

  it 'is valid with valid attributes' do
    expect(@valid_textbook).to be_valid
  end

  it 'is not valid with a phony isbn' do
    expect { @invalid_textbook.get_details }.to raise_error(NoMethodError)
  end
end
