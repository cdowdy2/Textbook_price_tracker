require 'rails_helper'
RSpec.describe WatchlistTextbook, type: :model do
  before(:example) do
    @user = create(:user)
    @textbook = create(:textbook, :valid)
  end

  it 'is not valid with without textbook reference' do
    expect { @user.watchlist_textbooks.create! }.to raise_error(ActiveRecord::RecordInvalid)
  end

  it 'is valid with user and valid textbook' do
    expect(@user.watchlist_textbooks.create!(textbook: @textbook)).to be_valid
  end

  it 'is not valid because user cannot watchlist the same textbook twice' do
    # First is okay.
    expect(@user.watchlist_textbooks.create!(textbook: @textbook)).to be_valid

    expect { @user.watchlist_textbooks.create!(textbook: @textbook) }.to raise_error(ActiveRecord::RecordInvalid)
  end
end
