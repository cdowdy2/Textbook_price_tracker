require 'rails_helper'
RSpec.describe TextbookPrice, type: :model do
  before(:example) do
    @url = 'https://www.cheapesttextbooks.com/abebooks/redirect/usedmkt/9780077366742.html?PID=31314596974&percent_savings=97'
    @valid_textbook = create(:textbook, :valid)
    @invalid_textbook = build(:textbook, :invalid)
    @previous_price = create(:textbook_price, :used, :has_url, :previous, textbook: @valid_textbook)
  end

  it 'is not valid with duplicate date' do
    @valid_textbook.textbook_prices.create(price: 10.99, date: DateTime.now.to_date,
                                           medium_type: :used, url: @url)

    textbook_price = @valid_textbook.textbook_prices.create(price: 10.99, date: DateTime.now.to_date,
                                                            medium_type: :used, url: @url)
    expect(textbook_price).to_not be_valid
  end

  it 'is not valid with phony medium type' do
    expect do
      @valid_textbook.textbook_prices.new(price: 10.99, date: DateTime.now.to_date + 1.day,
                                          medium_type: :phony, url: @url)
    end.to raise_error(ArgumentError)
  end

  it 'is not valid if price is not present when url is present' do
    expect(
      @valid_textbook.textbook_prices.create(date: DateTime.now.to_date + 1.day,
                                             medium_type: :brand_new, url: @url)
    ).to_not be_valid
  end

  it 'is valid without url if price is not present (unavailable)' do
    expect(
      @valid_textbook.textbook_prices.new(date: DateTime.now.to_date + 1.day,
                                          medium_type: :used)
    ).to be_valid
  end
end
