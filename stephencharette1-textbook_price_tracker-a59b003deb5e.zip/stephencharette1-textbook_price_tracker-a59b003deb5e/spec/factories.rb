FactoryBot.define do
  factory :user do
    email { 'joe@gmail.com' }
    password { 'blah123!' }
  end

  factory :textbook do
    trait :valid do
      isbn_13 { '9780077366742' }
    end

    trait :invalid do
      isbn_10 { '99999' }
    end
  end

  factory :textbook_price do
    price { 100 }

    trait :previous do
      date { DateTime.now.to_date - 1.day }
    end

    trait :aggregate do
      url { nil }
      price { 100.5 }
    end

    trait :unavailable do
      url { nil }
      price { nil }
    end

    trait :used do
      medium_type { :used }
    end

    trait :has_url do
      url { 'https://book-strike.herokuapp.com/' }
    end

    trait :brand_new do
      medium_type { :brand_new }
    end
  end
end
